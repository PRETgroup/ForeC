We are compiling binutils only to get create the modified
version of objdump. This new version will correctly intermix 
the source lines and the ARM assembly.

Step 1:
-------
Download binutils-2.22.51 from the GNU snapshots directory:
ftp://sourceware.org/pub/binutils/snapshots/

Step 2:
-------
Decompress the file. You should end up with a folder called
binutils-2.22.51. Copy the modified objdump.c file into the 
folder ./binutils-2.22.51/binutils

Step 3:
-------
Setup the build environment:
  $ export target=arm-linux-gnueabi
  $ cd binutils-2.22.51
  $ mkdir build-$target
  $ cd build-$target
  $ ../configure --target=$target --enable-interwork --enable-multilib --disable-nls --disable-shared --disable-threads --disable-werror --with-gcc --with-gnu-as --with-gnu-l

Step 4:
-------
Build the binaries:
  $ make

Step 5:
-------
The newly compiled objdump is located in:
./binutils-2.22.51/build-$target/binutils


