
.*:     file format elf32-.*arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
[0-9a-f]+ R_ARM_TLS_DTPMOD32  lib_gd2
[0-9a-f]+ R_ARM_TLS_DTPOFF32  lib_gd2
[0-9a-f]+ R_ARM_TLS_DTPMOD32  lib_gd
[0-9a-f]+ R_ARM_TLS_DTPOFF32  lib_gd
[0-9a-f]+ R_ARM_TLS_DESC    lib_gd2
